# Project 1
# Use RMI to implement a simple chat system.  
# Name: Jatin K rai
# DawID

import sys
import time

#This is for chat users.
class ChatUsers():

    availableusers = ()

    def __init__(self):
        self.availableusers = (('Jatin', '127.0.0.1', '9999'), ('Shajesh', '127.0.0.1', '3449'), ('Edward', '127.0.0.1', '3460'),
                           ('David', '127.0.0.1', '3333') )

    def getUsers (self):
        if (len(self.availableusers) > 0):
            return self.availableusers
        else:
             return None
  

    def getUserIPAddress (self, username):
        useripaddress = ''
        for user in   self.availableusers:
             if (user[0] == username):
                 useripaddress = user[1]
                 break;
             else:
                 useripaddress = ''

        return useripaddress
    
    def getUserPort (self, username):
        userportnumber = ''
        for user in   self.availableusers:
             if (user[0] == username):
                 userportnumber = user[2]
                 break;
             else:
                 userportnumber = ''

        return userportnumber
    
"""
    #Test cases and Test code
    objUser = ChatUsers()

    listusers  = objUser.getUsers()
    useripaddress= objUser.getUserIPAddress('Edward')
    userport= objUser.getUserPort('Edward')
"""
